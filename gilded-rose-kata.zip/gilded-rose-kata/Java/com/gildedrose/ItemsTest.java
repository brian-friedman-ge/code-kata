package com.gildedrose;

import static org.junit.Assert.*;

import org.junit.Test;

public class ItemsTest {

	@Test
	public void testAllItemsCount() {
		assertEquals(9, TestData.getTestItems().length);
	}
	
	@Test
	public void testEachItemCount() {
		Item[] testItems = TestData.getTestItems();
		Item[] passes = Items.getItems(testItems, "Backstage passes to a TAFKAL80ETC concert");
		Item[] sulfuras = Items.getItems(testItems, "Sulfuras, Hand of Ragnaros");
		Item[] brie = Items.getItems(testItems, "Aged Brie");
		Item[] conjured = Items.getItems(testItems, "Conjured Mana Cake");
		Item[] elixir = Items.getItems(testItems, "Elixir of the Mongoose");
		Item[] vest = Items.getItems(testItems, "+5 Dexterity Vest");
		
		assertEquals(1, vest.length);
		assertEquals(1, elixir.length);
		assertEquals(1, conjured.length);
		assertEquals(1, brie.length);
		assertEquals(2, sulfuras.length);
		assertEquals(3, passes.length);
	}
	
	@Test
	public void testIsNormalItem() {
		int expectedNormal = 2;
		int foundNormal = 0;
		Item[] items = TestData.getTestItems();
		for(int i = 0; i < items.length; i++) {
			if(Items.isNormal(items[i])) foundNormal++;
		}
		assertEquals(expectedNormal, foundNormal);
	}
	
	@Test
	public void testIsConjuredItem() {
		int expectedConjured = 1;
		int foundConjured = 0;
		Item[] items = TestData.getTestItems();
		for(int i =0; i < items.length;i++) {
			if(Items.isConjured(items[i]))
				foundConjured++;
		}
		assertEquals(expectedConjured, foundConjured);
	}
	
	@Test
	public void testIsBrie() {
		int expectedBrie = 1;
		int foundBrie = 0;
		Item[] items = TestData.getTestItems();
		for(int i =0; i < items.length;i++) {
			if(Items.isBrie(items[i]))
				foundBrie++;
		}
		assertEquals(expectedBrie, foundBrie);
	}

	@Test
	public void testIsSulfuras() {
		int expectedSulfuras = 2;
		int foundSulfuras = 0;
		Item[] items = TestData.getTestItems();
		for(int i =0; i < items.length;i++) {
			if(Items.isSulfuras(items[i]))
				foundSulfuras++;
		}
		assertEquals(expectedSulfuras, foundSulfuras);
	}
	
	@Test
	public void testIsBackstagePass() {
		int expectedPasses = 3;
		int foundPasses = 0;
		Item[] items = TestData.getTestItems();
		for(int i =0; i < items.length;i++) {
			if(Items.isBackstagePass(items[i]))
				foundPasses++;
		}
		assertEquals(expectedPasses, foundPasses);
	}
}
