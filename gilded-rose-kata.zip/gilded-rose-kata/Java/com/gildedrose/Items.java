package com.gildedrose;

import java.util.ArrayList;
import java.util.List;

public class Items {
	public static final String SPECIAL_ITEM_SULFURAS = "Sulfuras, Hand of Ragnaros";
	public static final String SPECIAL_ITEM_BRIE = "Aged Brie";
	public static final String SPECIAL_PREFIX_BACKSTAGE_PASS = "Backstage pass";
	public static final String SPECIAL_PREFIX_CONJURED = "Conjured";
	
	public static boolean isConjured(Item item) {
		return null != item && null != item.name && item.name.startsWith(SPECIAL_PREFIX_CONJURED);
	}
	
	public static boolean isNormal(Item item) {
		return !(isConjured(item) || isBrie(item) || isBackstagePass(item) || isSulfuras(item));
	}
	
	public static boolean isBrie(Item item) {
		return 0 == SPECIAL_ITEM_BRIE.compareTo(item.name);
	}
	
	public static boolean isBackstagePass(Item item) {
		return null != item 
					&& null != item.name 
					&& item.name.startsWith(SPECIAL_PREFIX_BACKSTAGE_PASS);
	}
	
	public static boolean isSulfuras(Item item) {
		return 0 == SPECIAL_ITEM_SULFURAS.compareTo(item.name);
	}
	
	public static Item[] getItems(Item[] items, String itemName) {
		List<Item> found = new ArrayList<Item>();
		for(Item item : items) {
			if(itemName.compareTo(item.name) == 0)
				found.add(item);
		}
		return found.toArray(new Item[found.size()]);
	}

}
