package com.gildedrose;

import static org.junit.Assert.*;

import org.junit.Test;

public class GildedRoseTest {

    @Test
    public void foo() {
        Item[] items = new Item[] { new Item("foo", 0, 0) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals("foo", app.items[0].name);
    }
    
    @Test
    public void testSulfurasDoesNotDecay() {
    	Item[] items = getItems(Items.SPECIAL_ITEM_SULFURAS);
    	Item testItem = items[0];
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	assertEquals(qualityBefore, testItem.quality);
    }
    
    @Test
    public void testSulfurasDoesNotExpire() {
    	Item[] items = getItems(Items.SPECIAL_ITEM_SULFURAS);
    	Item testItem = items[0];
    	int expiryBefore = testItem.sellIn;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	assertEquals(expiryBefore, testItem.sellIn);
    }
    
    @Test
    public void testBackstagePassesDecayRateWithExpiry_Gt_10() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 11;
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	int decayRate = qualityBefore - testItem.quality;
    	assertEquals(-1, decayRate);
    }
    
    @Test
    public void testBackstagePassesDecayRateWithExpiry_Lte_10_Gt_5_UpperBound() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 10;
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	int decayRate = qualityBefore - testItem.quality;
    	assertEquals(-2, decayRate);
    }
    
    @Test
    public void testBackstagePassesDecayRateWithExpiry_Lte_10_Gt_5_LowerBound() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 6;
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	int decayRate = qualityBefore - testItem.quality;
    	assertEquals(-2, decayRate);
    }
    
    @Test
    public void testBackstagePassesDecayRateWithExpiry_Lte_5_Gte_0_UpperBound() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 5;
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	int decayRate = qualityBefore - testItem.quality;
    	assertEquals(-3, decayRate);
    }
    
    @Test
    public void testBackstagePassesDecayRateWithExpiry_Lte_5_Gte_0_LowerBound() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 1;
    	int qualityBefore = testItem.quality;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	int decayRate = qualityBefore - testItem.quality;
    	assertEquals(-3, decayRate);
    }
    
    @Test
    public void testBackstagePassesQualityMaxAt50() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 10;
    	testItem.quality = 45;
    	int expectedQuality = 50;
    	
    	GildedRose app = new GildedRose(items);
    	for(int i = 0; i < 10; i++) app.updateQuality();
    	
    	assertEquals(expectedQuality, testItem.quality);
    }
    
    @Test
    public void testBackstagePassesExpire() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 0;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	assertEquals(-1, testItem.sellIn);
    }
    
    @Test
    public void testBackstagePassesHaveNoValueOnExpire() {
    	Item[] items = getItems();
    	Item testItem = getBackstagePass(items);
    	testItem.sellIn = 0;
    	testItem.quality = 49;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	assertEquals(0, testItem.quality);
    }
    
    @Test
    public void testBrieQualityIncreasesWithAge() {
    	Item[] items = getItems(Items.SPECIAL_ITEM_BRIE);
    	Item testItem = items[0];
    	int qualityExpected = testItem.quality + 1;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();
    	
    	assertEquals(qualityExpected, testItem.quality);
    }
    
    @Test
    public void testBrieQualityNever_Gt_50() {
    	Item[] items = getItems(Items.SPECIAL_ITEM_BRIE);
    	Item testItem = items[0];
        int qualityExpected = 50;
        
    	GildedRose app = new GildedRose(items);
    	for(int i = 0; i < 100; i++) app.updateQuality();
    	
    	assertEquals(qualityExpected, testItem.quality);
    }
    
    @Test
    public void testNormalQualityNever_Lt_0() {
    	Item[] items = getItems();
    	Item testItem = getNormalItem(items);
        int qualityExpected = 0;
        
    	GildedRose app = new GildedRose(items);
    	for(int i = 0; i < 100; i++) app.updateQuality();
    	
    	assertEquals(qualityExpected, testItem.quality);
    }
    
    @Test
    public void testNormalItemSellInReducedBy1() {
    	Item[] items = getItems();
    	Item testItem = getNormalItem(items);
    	int expectedExpiry = testItem.sellIn - 1;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();

    	assertEquals(expectedExpiry, testItem.sellIn);
    }
    
    @Test
    public void testNormalItemQualityDecaysByOneIfSellIn_Gt_0() {
    	Item[] items = getItems();
    	Item testItem = getNormalItem(items);
    	testItem.sellIn = 1;
    	int expectedQuality = testItem.quality - 1;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();

    	assertEquals(expectedQuality, testItem.quality);
    }
    
    @Test
    public void testNormalItemQualityDecaysByTwoIfSellIn_Lte_0() {
    	Item[] items = getItems();
    	Item testItem = getNormalItem(items);
    	testItem.sellIn = 0;
    	int expectedQuality = testItem.quality - 2;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();

    	assertEquals(expectedQuality, testItem.quality);
    }

    @Test
    public void testConjuredItemSellInReducedBy1() {
    	Item[] items = getItems();
    	Item testItem = getConjuredItem(items);
    	testItem.sellIn = 10;
    	int expectedExpiry = testItem.sellIn - 1;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();

    	assertEquals(expectedExpiry, testItem.sellIn);
    }
    
    @Test
    public void testConjuredItemDecayRateIsTwiceNormal() {
    	Item[] items = getItems();
    	Item testItem = getConjuredItem(items);
    	Item normalItem = getNormalItem(items);
    	int normalQualityBefore = normalItem.quality;
    	int testQualityBefore = testItem.quality;
    	
    	testItem.sellIn = 10;
    	normalItem.sellIn = 10;
    	
    	GildedRose app = new GildedRose(items);
    	app.updateQuality();

    	int normalDecay = normalQualityBefore - normalItem.quality;
    	int testDecay = testQualityBefore - testItem.quality;
    	int expectedConjuredDecay = 2 * normalDecay;
    	assertEquals(expectedConjuredDecay, testDecay);
    }
    
    static Item[] getItems() {
    	return TestData.getTestItems();
    }
    
    static Item[] getItems(String itemName) {
    	return Items.getItems(TestData.getTestItems(), itemName);
    }
    
    static Item getConjuredItem(Item[] items) {
    	for(Item item : items) 
    		if(Items.isConjured(item))
    			return item;
    	
    	return null;
    }
    
    static Item getNormalItem(Item[] items) {
    	for(Item item : items) 
    		if(Items.isNormal(item))
    			return item;
    	
    	return null;
    }
    
    static Item getBackstagePass(Item[] items) {
    	for(Item item : items) 
    		if(Items.isBackstagePass(item))
    			return item;
    	
    	return null;
    }
}
