package com.gildedrose;

class GildedRose {
	static final int MAX_QUALITY = 50;
	
    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        for (int i = 0; i < items.length; i++) {
        	// get the current item
        	Item item = items[i];
        	// don't touch Sulfuras!!
        	if(Items.isSulfuras(item)) continue;

        	// normal and conjured items decay over time...
        	if(Items.isNormal(item) || Items.isConjured(item)) {
        		int decay = 1;
        		if(item.sellIn <= 0) {
        			decay *= 2;
        		}
        		if(Items.isConjured(item)) {
        			decay *= 2;
        		}
        		item.quality -= decay;
        	}
        	// brie is a vintage item and gains quality over time
        	else if(Items.isBrie(item)) {
        		item.quality++;
        	}
        	// backstage passes are high demand and gain value
        	// more rapidly as event date approaches
        	else if(Items.isBackstagePass(item)) {
        		if(item.sellIn <= 0) {
        			item.quality = 0;
        		}
        		else if(item.sellIn >= 0 && item.sellIn <= 5) {
        			item.quality += 3;
        		}
        		else if(item.sellIn > 5 && item.sellIn <= 10) {
        			item.quality += 2;
        		}
        		else {
        			item.quality++;
        		}
        	}
        	// all items have the expiry decreased by 1
        	item.sellIn--;
        	// some global rules for min and max quality
        	if(item.quality > MAX_QUALITY) {
        		item.quality = MAX_QUALITY;
        	}
        	else if(item.quality < 0) {
        		item.quality = 0;
        	}
        }
    }
}
